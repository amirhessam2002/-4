﻿namespace IranianProduct
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.picBoxForeign1 = new System.Windows.Forms.PictureBox();
            this.picBoxForeign2 = new System.Windows.Forms.PictureBox();
            this.picBoxForeign3 = new System.Windows.Forms.PictureBox();
            this.picBoxForeign4 = new System.Windows.Forms.PictureBox();
            this.picBoxCrab1 = new System.Windows.Forms.PictureBox();
            this.picBoxCrab2 = new System.Windows.Forms.PictureBox();
            this.picBoxCrab3 = new System.Windows.Forms.PictureBox();
            this.picBoxIran1 = new System.Windows.Forms.PictureBox();
            this.picBoxIran2 = new System.Windows.Forms.PictureBox();
            this.picBoxIran3 = new System.Windows.Forms.PictureBox();
            this.picBoxIran4 = new System.Windows.Forms.PictureBox();
            this.picBoxMan = new System.Windows.Forms.PictureBox();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCrab1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCrab2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCrab3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMan)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox1.Location = new System.Drawing.Point(13, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox2.Location = new System.Drawing.Point(69, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox3.Location = new System.Drawing.Point(125, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox4.Location = new System.Drawing.Point(181, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox5.Location = new System.Drawing.Point(237, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox6.Location = new System.Drawing.Point(293, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox7.Location = new System.Drawing.Point(349, 12);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 50);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox8.Location = new System.Drawing.Point(405, 12);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(50, 50);
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox9.Location = new System.Drawing.Point(461, 12);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(50, 50);
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox10.Location = new System.Drawing.Point(517, 12);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(50, 50);
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox11.Location = new System.Drawing.Point(573, 12);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(50, 50);
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox12.Location = new System.Drawing.Point(573, 68);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(50, 50);
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox13.Location = new System.Drawing.Point(573, 124);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(50, 50);
            this.pictureBox13.TabIndex = 0;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox14.Location = new System.Drawing.Point(573, 180);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(50, 50);
            this.pictureBox14.TabIndex = 0;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox15.Location = new System.Drawing.Point(573, 236);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(50, 50);
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox16.Location = new System.Drawing.Point(573, 292);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(50, 50);
            this.pictureBox16.TabIndex = 0;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox17.Location = new System.Drawing.Point(573, 348);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(50, 50);
            this.pictureBox17.TabIndex = 0;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox18.Location = new System.Drawing.Point(573, 404);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(50, 50);
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox19.Location = new System.Drawing.Point(573, 460);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(50, 50);
            this.pictureBox19.TabIndex = 0;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox20.Location = new System.Drawing.Point(573, 516);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(50, 50);
            this.pictureBox20.TabIndex = 0;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox21.Location = new System.Drawing.Point(517, 516);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(50, 50);
            this.pictureBox21.TabIndex = 0;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox22.Location = new System.Drawing.Point(461, 516);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(50, 50);
            this.pictureBox22.TabIndex = 0;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox23.Location = new System.Drawing.Point(405, 516);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(50, 50);
            this.pictureBox23.TabIndex = 0;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox24.Location = new System.Drawing.Point(349, 516);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(50, 50);
            this.pictureBox24.TabIndex = 0;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox25.Location = new System.Drawing.Point(293, 516);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(50, 50);
            this.pictureBox25.TabIndex = 0;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox26.Location = new System.Drawing.Point(237, 516);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(50, 50);
            this.pictureBox26.TabIndex = 0;
            this.pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox27.Location = new System.Drawing.Point(181, 516);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(50, 50);
            this.pictureBox27.TabIndex = 0;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox28.Location = new System.Drawing.Point(125, 516);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(50, 50);
            this.pictureBox28.TabIndex = 0;
            this.pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox29.Location = new System.Drawing.Point(69, 516);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(50, 50);
            this.pictureBox29.TabIndex = 0;
            this.pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox30.Location = new System.Drawing.Point(13, 516);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(50, 50);
            this.pictureBox30.TabIndex = 0;
            this.pictureBox30.TabStop = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox31.Location = new System.Drawing.Point(13, 460);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(50, 50);
            this.pictureBox31.TabIndex = 0;
            this.pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox32.Location = new System.Drawing.Point(13, 404);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(50, 50);
            this.pictureBox32.TabIndex = 0;
            this.pictureBox32.TabStop = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox33.Location = new System.Drawing.Point(13, 348);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(50, 50);
            this.pictureBox33.TabIndex = 0;
            this.pictureBox33.TabStop = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox34.Location = new System.Drawing.Point(13, 292);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(50, 50);
            this.pictureBox34.TabIndex = 0;
            this.pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox35.Location = new System.Drawing.Point(13, 236);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(50, 50);
            this.pictureBox35.TabIndex = 0;
            this.pictureBox35.TabStop = false;
            // 
            // pictureBox36
            // 
            this.pictureBox36.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox36.Location = new System.Drawing.Point(13, 180);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(50, 50);
            this.pictureBox36.TabIndex = 0;
            this.pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox37.Location = new System.Drawing.Point(13, 124);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(50, 50);
            this.pictureBox37.TabIndex = 0;
            this.pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox38.Location = new System.Drawing.Point(13, 68);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(50, 50);
            this.pictureBox38.TabIndex = 0;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox39.Location = new System.Drawing.Point(237, 68);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(50, 50);
            this.pictureBox39.TabIndex = 0;
            this.pictureBox39.TabStop = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox40.Location = new System.Drawing.Point(349, 124);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(50, 50);
            this.pictureBox40.TabIndex = 0;
            this.pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox41.Location = new System.Drawing.Point(405, 124);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(50, 50);
            this.pictureBox41.TabIndex = 0;
            this.pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox42.Location = new System.Drawing.Point(125, 180);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(50, 50);
            this.pictureBox42.TabIndex = 0;
            this.pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox43.Location = new System.Drawing.Point(237, 180);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(50, 50);
            this.pictureBox43.TabIndex = 0;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox44.Location = new System.Drawing.Point(349, 180);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(50, 50);
            this.pictureBox44.TabIndex = 0;
            this.pictureBox44.TabStop = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox45.Location = new System.Drawing.Point(461, 180);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(50, 50);
            this.pictureBox45.TabIndex = 0;
            this.pictureBox45.TabStop = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox46.Location = new System.Drawing.Point(125, 236);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(50, 50);
            this.pictureBox46.TabIndex = 0;
            this.pictureBox46.TabStop = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox47.Location = new System.Drawing.Point(405, 236);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(50, 50);
            this.pictureBox47.TabIndex = 0;
            this.pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox48.Location = new System.Drawing.Point(125, 292);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(50, 50);
            this.pictureBox48.TabIndex = 0;
            this.pictureBox48.TabStop = false;
            // 
            // pictureBox49
            // 
            this.pictureBox49.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox49.Location = new System.Drawing.Point(237, 292);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(50, 50);
            this.pictureBox49.TabIndex = 0;
            this.pictureBox49.TabStop = false;
            // 
            // pictureBox50
            // 
            this.pictureBox50.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox50.Location = new System.Drawing.Point(405, 292);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(50, 50);
            this.pictureBox50.TabIndex = 0;
            this.pictureBox50.TabStop = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox51.Location = new System.Drawing.Point(293, 348);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(50, 50);
            this.pictureBox51.TabIndex = 0;
            this.pictureBox51.TabStop = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox52.Location = new System.Drawing.Point(349, 348);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(50, 50);
            this.pictureBox52.TabIndex = 0;
            this.pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            this.pictureBox53.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox53.Location = new System.Drawing.Point(405, 348);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(50, 50);
            this.pictureBox53.TabIndex = 0;
            this.pictureBox53.TabStop = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox54.Location = new System.Drawing.Point(461, 348);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(50, 50);
            this.pictureBox54.TabIndex = 0;
            this.pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox55.Location = new System.Drawing.Point(181, 404);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(50, 50);
            this.pictureBox55.TabIndex = 0;
            this.pictureBox55.TabStop = false;
            // 
            // pictureBox56
            // 
            this.pictureBox56.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox56.Location = new System.Drawing.Point(237, 404);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(50, 50);
            this.pictureBox56.TabIndex = 0;
            this.pictureBox56.TabStop = false;
            // 
            // pictureBox57
            // 
            this.pictureBox57.Image = global::IranianProduct.Properties.Resources.wall;
            this.pictureBox57.Location = new System.Drawing.Point(461, 460);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(50, 50);
            this.pictureBox57.TabIndex = 0;
            this.pictureBox57.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(295, 595);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = ": امتیاز";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(273, 596);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "0";
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnStart.Location = new System.Drawing.Point(13, 581);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(85, 50);
            this.btnStart.TabIndex = 3;
            this.btnStart.TabStop = false;
            this.btnStart.Text = "شروع";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.Location = new System.Drawing.Point(104, 581);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 50);
            this.button1.TabIndex = 3;
            this.button1.TabStop = false;
            this.button1.Text = "پایان";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // picBoxForeign1
            // 
            this.picBoxForeign1.Image = global::IranianProduct.Properties.Resources.Foreign;
            this.picBoxForeign1.Location = new System.Drawing.Point(69, 68);
            this.picBoxForeign1.Name = "picBoxForeign1";
            this.picBoxForeign1.Size = new System.Drawing.Size(50, 50);
            this.picBoxForeign1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxForeign1.TabIndex = 4;
            this.picBoxForeign1.TabStop = false;
            // 
            // picBoxForeign2
            // 
            this.picBoxForeign2.Image = global::IranianProduct.Properties.Resources.Foreign;
            this.picBoxForeign2.Location = new System.Drawing.Point(517, 68);
            this.picBoxForeign2.Name = "picBoxForeign2";
            this.picBoxForeign2.Size = new System.Drawing.Size(50, 50);
            this.picBoxForeign2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxForeign2.TabIndex = 4;
            this.picBoxForeign2.TabStop = false;
            // 
            // picBoxForeign3
            // 
            this.picBoxForeign3.Image = global::IranianProduct.Properties.Resources.Foreign;
            this.picBoxForeign3.Location = new System.Drawing.Point(69, 460);
            this.picBoxForeign3.Name = "picBoxForeign3";
            this.picBoxForeign3.Size = new System.Drawing.Size(50, 50);
            this.picBoxForeign3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxForeign3.TabIndex = 4;
            this.picBoxForeign3.TabStop = false;
            // 
            // picBoxForeign4
            // 
            this.picBoxForeign4.Image = global::IranianProduct.Properties.Resources.Foreign;
            this.picBoxForeign4.Location = new System.Drawing.Point(517, 460);
            this.picBoxForeign4.Name = "picBoxForeign4";
            this.picBoxForeign4.Size = new System.Drawing.Size(50, 50);
            this.picBoxForeign4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxForeign4.TabIndex = 4;
            this.picBoxForeign4.TabStop = false;
            // 
            // picBoxCrab1
            // 
            this.picBoxCrab1.Image = global::IranianProduct.Properties.Resources.crab;
            this.picBoxCrab1.Location = new System.Drawing.Point(181, 180);
            this.picBoxCrab1.Name = "picBoxCrab1";
            this.picBoxCrab1.Size = new System.Drawing.Size(50, 50);
            this.picBoxCrab1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxCrab1.TabIndex = 5;
            this.picBoxCrab1.TabStop = false;
            // 
            // picBoxCrab2
            // 
            this.picBoxCrab2.Image = global::IranianProduct.Properties.Resources.crab;
            this.picBoxCrab2.Location = new System.Drawing.Point(405, 180);
            this.picBoxCrab2.Name = "picBoxCrab2";
            this.picBoxCrab2.Size = new System.Drawing.Size(50, 50);
            this.picBoxCrab2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxCrab2.TabIndex = 5;
            this.picBoxCrab2.TabStop = false;
            // 
            // picBoxCrab3
            // 
            this.picBoxCrab3.Image = global::IranianProduct.Properties.Resources.crab;
            this.picBoxCrab3.Location = new System.Drawing.Point(237, 348);
            this.picBoxCrab3.Name = "picBoxCrab3";
            this.picBoxCrab3.Size = new System.Drawing.Size(50, 50);
            this.picBoxCrab3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxCrab3.TabIndex = 5;
            this.picBoxCrab3.TabStop = false;
            // 
            // picBoxIran1
            // 
            this.picBoxIran1.Image = global::IranianProduct.Properties.Resources.iran;
            this.picBoxIran1.Location = new System.Drawing.Point(461, 236);
            this.picBoxIran1.Name = "picBoxIran1";
            this.picBoxIran1.Size = new System.Drawing.Size(50, 50);
            this.picBoxIran1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxIran1.TabIndex = 6;
            this.picBoxIran1.TabStop = false;
            // 
            // picBoxIran2
            // 
            this.picBoxIran2.Image = global::IranianProduct.Properties.Resources.iran;
            this.picBoxIran2.Location = new System.Drawing.Point(293, 292);
            this.picBoxIran2.Name = "picBoxIran2";
            this.picBoxIran2.Size = new System.Drawing.Size(50, 50);
            this.picBoxIran2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxIran2.TabIndex = 6;
            this.picBoxIran2.TabStop = false;
            // 
            // picBoxIran3
            // 
            this.picBoxIran3.Image = global::IranianProduct.Properties.Resources.iran;
            this.picBoxIran3.Location = new System.Drawing.Point(125, 348);
            this.picBoxIran3.Name = "picBoxIran3";
            this.picBoxIran3.Size = new System.Drawing.Size(50, 50);
            this.picBoxIran3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxIran3.TabIndex = 6;
            this.picBoxIran3.TabStop = false;
            // 
            // picBoxIran4
            // 
            this.picBoxIran4.Image = global::IranianProduct.Properties.Resources.iran;
            this.picBoxIran4.Location = new System.Drawing.Point(349, 460);
            this.picBoxIran4.Name = "picBoxIran4";
            this.picBoxIran4.Size = new System.Drawing.Size(50, 50);
            this.picBoxIran4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxIran4.TabIndex = 6;
            this.picBoxIran4.TabStop = false;
            // 
            // picBoxMan
            // 
            this.picBoxMan.Image = global::IranianProduct.Properties.Resources.man;
            this.picBoxMan.Location = new System.Drawing.Point(237, 460);
            this.picBoxMan.Name = "picBoxMan";
            this.picBoxMan.Size = new System.Drawing.Size(50, 50);
            this.picBoxMan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxMan.TabIndex = 7;
            this.picBoxMan.TabStop = false;
            // 
            // btnDown
            // 
            this.btnDown.Image = global::IranianProduct.Properties.Resources.down;
            this.btnDown.Location = new System.Drawing.Point(398, 582);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(50, 50);
            this.btnDown.TabIndex = 8;
            this.btnDown.TabStop = false;
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnUp
            // 
            this.btnUp.Image = global::IranianProduct.Properties.Resources.top;
            this.btnUp.Location = new System.Drawing.Point(454, 582);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(50, 50);
            this.btnUp.TabIndex = 8;
            this.btnUp.TabStop = false;
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.Image = global::IranianProduct.Properties.Resources.left;
            this.btnLeft.Location = new System.Drawing.Point(510, 582);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(50, 50);
            this.btnLeft.TabIndex = 8;
            this.btnLeft.TabStop = false;
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnRight
            // 
            this.btnRight.Image = global::IranianProduct.Properties.Resources.right;
            this.btnRight.Location = new System.Drawing.Point(565, 582);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(50, 50);
            this.btnRight.TabIndex = 8;
            this.btnRight.TabStop = false;
            this.btnRight.UseVisualStyleBackColor = true;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 646);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.picBoxMan);
            this.Controls.Add(this.picBoxIran4);
            this.Controls.Add(this.picBoxIran3);
            this.Controls.Add(this.picBoxIran2);
            this.Controls.Add(this.picBoxIran1);
            this.Controls.Add(this.picBoxCrab3);
            this.Controls.Add(this.picBoxCrab2);
            this.Controls.Add(this.picBoxCrab1);
            this.Controls.Add(this.picBoxForeign4);
            this.Controls.Add(this.picBoxForeign3);
            this.Controls.Add(this.picBoxForeign2);
            this.Controls.Add(this.picBoxForeign1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox28);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "بازی کالای ایرانی";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxForeign4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCrab1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCrab2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCrab3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIran4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox picBoxForeign1;
        private System.Windows.Forms.PictureBox picBoxForeign2;
        private System.Windows.Forms.PictureBox picBoxForeign3;
        private System.Windows.Forms.PictureBox picBoxForeign4;
        private System.Windows.Forms.PictureBox picBoxCrab1;
        private System.Windows.Forms.PictureBox picBoxCrab2;
        private System.Windows.Forms.PictureBox picBoxCrab3;
        private System.Windows.Forms.PictureBox picBoxIran1;
        private System.Windows.Forms.PictureBox picBoxIran2;
        private System.Windows.Forms.PictureBox picBoxIran3;
        private System.Windows.Forms.PictureBox picBoxIran4;
        private System.Windows.Forms.PictureBox picBoxMan;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRight;
    }
}

